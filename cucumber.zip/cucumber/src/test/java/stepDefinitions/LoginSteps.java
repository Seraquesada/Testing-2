package stepDefinitions;

import static org.junit.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps {
	WebDriver driver;
	By email = By.name("email");
	By password = By.name("password");
	By botonLogin = By.linkText("Iniciar sesión");
	By botonIngresar = By.xpath("//*[@id=\"root\"]/main/div/form/button");
	By resultado= By.className("txt-nombre");
	
	@Given("abrir pagina")
	public void abrir_pagina() {
		System.setProperty("webdriver.chrome.driver",".\\src\\test\\resources\\driver\\chromedriver.exe");		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://testing.ctd.academy/");
	}

	@When("ingresar user y password")
	public void ingresar_user_y_password() {
		driver.findElement(email).sendKeys("edisson.g.p@hotmail.com");
		driver.findElement(password).sendKeys("pass123");
	}

	@When("click en boton login")
	public void click_en_boton_login() {
		driver.findElement(botonLogin).click();
	}

	@Then("se abre home page")
	public void se_abre_home_page() {
		String res = driver.findElement(resultado).getText();
		assertTrue(res.contains("edisson esteban gomez pinzon"));
	}
	@When("click en boton ingresar")
	public void click_en_boton_ingresar() throws InterruptedException {
		driver.findElement(botonIngresar).click();
		Thread.sleep(2000);
	}
	@Then("cerrar el navegador")
	public void cerrar_el_navegador() {
		driver.quit();
	}
}
