package Tests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class testLogin {
    WebDriver driver;
    By botonLogin = By.linkText("Iniciar sesión");
    By correo = By.name("email");
    By contrasena = By.id("password");
    By botonIngresar = By.xpath("//*[@id=\'root\']/main/div/form/button");
    By resultado = By.className("txt-nombre");
    By resultadoFail = By.className("form-feedback");

    @BeforeEach
    public void setUp() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver",".\\src\\test\\resources\\driver\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://testing.ctd.academy/");
        Thread.sleep(2000);
        String titulo = driver.getTitle();
        System.out.println(titulo);
        assertTrue(titulo.contains("Digital Booking"));
    }
    @Test
    public void loginExitoso() throws InterruptedException {
        driver.findElement(botonLogin).click();
        driver.findElement(correo).sendKeys("edisson.g.p@hotmail.com");
        driver.findElement(contrasena).sendKeys("pass123");
        driver.findElement(botonIngresar).click();
        Thread.sleep(2000);
        String res = driver.findElement(resultado).getText();
        assertTrue(res.contains("edisson esteban gomez pinzon"));
        Thread.sleep(2000);
        driver.quit();
    }
    @Test
    public void loginNoExitoso() throws InterruptedException {
        driver.findElement(botonLogin).click();
        driver.findElement(correo).sendKeys("edisson.g.p@hotmail.com");
        driver.findElement(contrasena).sendKeys("pass1234");
        driver.findElement(botonIngresar).click();
        Thread.sleep(2000);
        String res = driver.findElement(resultadoFail).getText();
        assertTrue(res.contains("Sus credenciales son inválidas. Por favor, vuelva a intentarlo"));
        driver.quit();
    }


}
