package Tests;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.junit.jupiter.api.Assertions.assertTrue;

class TestGoogle {

    WebDriver driver;
    By textBox = By.className("gLFyf");
    By botonSearch = By.xpath("/html/body/div[1]/div[3]/form/div[1]/div[1]/div[4]/center/input[1]");

    @BeforeEach
    public void setUp() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver",".\\src\\test\\resources\\driver\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://www.google.com/");
        Thread.sleep(2000);
        String titulo = driver.getTitle();
        System.out.println(titulo);
        assertTrue(titulo.contains("Google"));
    }
    @Test
    public void search() throws InterruptedException {
        driver.findElement(textBox).sendKeys("Selenium");
        driver.findElement(botonSearch).click();
        Thread.sleep(2000);
        driver.quit();
    }

}